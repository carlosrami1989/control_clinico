<?php

return [
    'router_prefix' => '/Empresa',
];
